﻿using System;

using NUnit.Framework;

using SchoolSystem.Framework.Models;

namespace SchoolSystem.Framework.Tests.Models
{
    [TestFixture]
    public class StudentTests
    {
        [TestCase(0)]
        [TestCase(13)]
        [TestCase(150000)]
        public void Constructor_ShouldThrow_WhenGradeParameterIsOutOfRange(int grade)
        {
            var firstName = "firstName";
            var lastName = "lastName";

            Assert.That(() => new Student(firstName, lastName, grade),
                Throws.InstanceOf<ArgumentOutOfRangeException>());
        }
    }
}
