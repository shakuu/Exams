using System.Collections.Generic;
using SchoolSystem.Framework.Commands.Contracts;
using SchoolSystem.Framework.Engines;
using SchoolSystem.Framework.Engines.Contracts;
using SchoolSystem.Framework.Models;

namespace SchoolSystem.Framework.Commands
{
    public class TeacherAddMarkCommand : ICommand
    {
        public string Execute(IList<string> prms, ISchoolSystemEngine engine)
        {
            var teecherid = int.Parse(prms[0]);
            var studentid = int.Parse(prms[1]);

            var student = engine.GetStudentWithId(studentid);
            var teacher = engine.GetTeacherWithId(teecherid);

            var markValue = float.Parse(prms[2]);
            var mark = SchoolSystemFactory.CreateMark(markValue);
            teacher.AddMark(student, mark);

            var result = $"Teacher {teacher.FirstName} {teacher.LastName} added mark {float.Parse(prms[2])} to student {student.FirstName} {student.LastName} in {teacher.SchoolSubjectType}.";
            return result;
        }
    }
}