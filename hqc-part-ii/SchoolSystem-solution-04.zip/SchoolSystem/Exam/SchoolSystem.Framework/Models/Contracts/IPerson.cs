﻿namespace SchoolSystem.Framework.Models.Contracts
{
    public interface IPerson
    {
        string FirstName { get; set; }

        string LastName { get; set; }
    }
}