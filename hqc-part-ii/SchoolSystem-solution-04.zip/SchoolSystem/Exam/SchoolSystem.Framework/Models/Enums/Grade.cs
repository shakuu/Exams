﻿namespace SchoolSystem.Framework.Models.Enums
{
    public enum Grade
    {
        NotSet = 0,
        First,
        Second,
        Third,
        Fourth,
        Fifth,
        Sixth,
        Seventh,
        Eighth,
        Ninth,
        Tenth,
        Eleventh,
        Twelfth
    }
}
