﻿namespace SchoolSystem.Framework.Models.Enums
{
    public enum SchoolSubjectType
    {
        Bulgarian,
        English,
        Math,
        Programming
    }
}
