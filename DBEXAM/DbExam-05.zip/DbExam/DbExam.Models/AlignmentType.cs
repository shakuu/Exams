﻿namespace DbExam.Models
{
    public enum AlignmentType
    {
        Neutral = 0,
        Good = 1,
        Evil = 2
    }
}