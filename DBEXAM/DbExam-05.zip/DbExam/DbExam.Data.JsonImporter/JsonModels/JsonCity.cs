﻿namespace DbExam.Data.JsonImporter.JsonModels
{
    /*
         "city": {
        "name": "Gotham",
        "country": "USA",
        "planet": "Earth"
      },
      "ali
      },*/
    public class JsonCity
    {
        public string name { get; set; }

        public string country { get; set; }

        public string planet { get; set; }
    }
}