﻿using System.Collections.Generic;

namespace DbExam.Data.JsonImporter.JsonModels
{
    public class JsonDataContainer
    {
        public List<JsonSuperhero> data { get; set; }
    }
}
