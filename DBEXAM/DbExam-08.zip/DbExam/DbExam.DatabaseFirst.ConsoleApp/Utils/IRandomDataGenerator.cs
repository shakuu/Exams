﻿namespace DbExam.DatabaseFirst.ConsoleApp.Utils
{
    public interface IRandomDataGenerator
    {
    }
}