﻿namespace DbExam.Models
{
    public interface INameable
    {
        string Name { get; set; }
    }
}