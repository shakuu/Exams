﻿using System.Reflection;

using Ninject;

using SchoolSystem.Framework.Core;
using SchoolSystem.Framework.Core.Factories;
using SchoolSystem.Framework.Models.Enums;

namespace SchoolSystem.Cli
{
    public class Startup
    {
        public static void Main()
        {
            var ninject = new StandardKernel();
            ninject.Load(Assembly.GetExecutingAssembly());

            //var t = ninject.Get<ITeacherFactory>().CreateTeacher("firstname", "lastname", Subject.Bulgarian);

            var engine = ninject.Get<IEngine>();
            engine.Start();
        }
    }
}