﻿namespace SchoolSystem.Framework.Core.Contracts
{
    public interface IIdentityProvider
    {
        int NextId();
    }
}
