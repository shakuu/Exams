﻿using System.Collections.Generic;

using SchoolSystem.Framework.Models.Contracts;

namespace SchoolSystem.Framework.Core
{
    public class SchoolSystemData : ISchoolSystemData
    {
        private readonly IDictionary<int, IStudent> students;
        private readonly IDictionary<int, ITeacher> teachers;

        public SchoolSystemData()
        {
            this.students = new Dictionary<int, IStudent>();
            this.teachers = new Dictionary<int, ITeacher>();
        }

        public IDictionary<int, IStudent> Students
        {
            get
            {
                return this.students;
            }
        }

        public IDictionary<int, ITeacher> Teachers
        {
            get
            {
                return this.teachers;
            }
        }
    }
}
