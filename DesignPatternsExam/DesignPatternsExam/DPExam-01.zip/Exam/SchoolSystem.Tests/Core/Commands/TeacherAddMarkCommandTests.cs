﻿using NUnit.Framework;
using Moq;

namespace SchoolSystem.Tests.Core.Commands
{
    [TestFixture]
    public class TeacherAddMarkCommandTests
    {
    }
}
