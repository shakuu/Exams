﻿using System.Collections.Generic;

using SchoolSystem.Framework.Models.Contracts;

namespace SchoolSystem.Framework.Core
{
    public interface ISchoolSystemData
    {
        ISchoolSystemDataCollection<ITeacher> Teachers { get; }

        ISchoolSystemDataCollection<IStudent> Students { get; }
    }
}
