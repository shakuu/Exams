﻿namespace SchoolSystem.Framework.Core
{
    public interface IEngine
    {
        void Start();
    }
}