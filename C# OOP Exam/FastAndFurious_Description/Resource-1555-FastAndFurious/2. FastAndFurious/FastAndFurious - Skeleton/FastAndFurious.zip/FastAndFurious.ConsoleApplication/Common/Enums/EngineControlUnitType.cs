﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum EngineControlUnitType
    {
        NotSet = 0,
        Stock,
        Performance,
        Pro
    }
}
