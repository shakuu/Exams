﻿using FastAndFurious.ConsoleApplication.Models.MotorVehicles.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastAndFurious.ConsoleApplication.Models.MotorVehicles
{
    /// <summary>
    /// 55999,1560000,260,35
    /// </summary>
    public class SubaruImprezaWRX : MotorVehicle
    {
        public SubaruImprezaWRX() 
            : base(55999, 1560000, 260, 35)
        {
        }
    }
}
