﻿namespace Dealership.Models
{
    public class VeryImportant
    {
        // Take a break once in awhile :)
        string url = "http://9gag.com";
    }
}
