﻿namespace Dealership.Contracts
{
    public interface IPriceable
    {
        decimal Price { get; }
    }
}
