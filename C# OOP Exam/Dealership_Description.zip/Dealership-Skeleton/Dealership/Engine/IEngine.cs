﻿namespace Dealership.Engine
{
    public interface IEngine
    {
        void Start();
    }
}
