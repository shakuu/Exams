﻿namespace IntergalacticTravel.Constants
{
    public class GlobalConstants
    {
        public const uint BronzeCoinsDefaultAmount = 0;
        public const uint SilverCoinsDefaultAmount = 0;
        public const uint GoldCoinsDefaultAmount = 0;
    }
}
