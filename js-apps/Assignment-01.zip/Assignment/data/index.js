/* globals module require */

"use strict";

module.exports = require("./data");