$(() => {
    appRouter.start('#content');
});