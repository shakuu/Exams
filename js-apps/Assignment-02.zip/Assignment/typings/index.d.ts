/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/sinon/index.d.ts" />
