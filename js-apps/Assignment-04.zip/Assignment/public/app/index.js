
$(() => {
    appRouter.start('#content');
});